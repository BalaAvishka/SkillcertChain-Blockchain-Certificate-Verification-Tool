package com.skincertchain;

import com.skincertchain.model.CertificateRecord;
import com.skincertchain.repository.CertificateRepository;
import com.skincertchain.service.BlockchainService;
import com.skincertchain.service.CertificateService;
import com.skincertchain.service.IpfsService;
import org.apache.commons.codec.digest.DigestUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CertificateServiceTest {

    @Mock  CertificateRepository repository;
    @Mock  BlockchainService     blockchainService;
    @Mock  IpfsService           ipfsService;
    @InjectMocks CertificateService service;

    private static final String ISSUER = "0xABCDEF0123456789abcdef0123456789ABCDEF01";

    // ── Issue ─────────────────────────────────────────────────────────────────

    @Test
    @DisplayName("issueCertificate – happy path saves record with tx hash")
    void issueCertificate_happyPath() throws Exception {
        byte[] content = "sample certificate content".getBytes();
        MockMultipartFile file = new MockMultipartFile("file", "cert.pdf",
                "application/pdf", content);

        String fakeCid  = "QmFakeCid1234";
        String fakeTx   = "0x" + "a".repeat(64);

        when(ipfsService.uploadFile(any())).thenReturn(fakeCid);
        when(blockchainService.issueCertificate(anyString(), anyString(), anyString(), anyString(), anyString()))
                .thenReturn(fakeTx);

        ArgumentCaptor<CertificateRecord> captor = ArgumentCaptor.forClass(CertificateRecord.class);
        when(repository.save(captor.capture())).thenAnswer(inv -> inv.getArgument(0));

        CertificateRecord result = service.issueCertificate(
                file, "Alice", "0x1234", "Java Dev", ISSUER
        );

        assertThat(result.getRecipientName()).isEqualTo("Alice");
        assertThat(result.getCourseName()).isEqualTo("Java Dev");
        assertThat(result.getIpfsCid()).isEqualTo(fakeCid);
        assertThat(result.getTxHash()).isEqualTo(fakeTx);
        assertThat(result.isRevoked()).isFalse();
        assertThat(result.getCertHash()).startsWith("0x");

        verify(repository, times(1)).save(any());
    }

    // ── Verify ────────────────────────────────────────────────────────────────

    @Test
    @DisplayName("verifyById – valid certificate returns VALID status")
    void verifyById_valid() {
        CertificateRecord rec = validRecord();
        when(repository.findByCertId("0xCertId123")).thenReturn(Optional.of(rec));

        CertificateService.VerificationResult result = service.verifyById("0xCertId123");

        assertThat(result.isValid()).isTrue();
        assertThat(result.certificate()).isEqualTo(rec);
    }

    @Test
    @DisplayName("verifyById – revoked certificate returns REVOKED status")
    void verifyById_revoked() {
        CertificateRecord rec = validRecord();
        rec.setRevoked(true);
        when(repository.findByCertId("0xCertId123")).thenReturn(Optional.of(rec));

        CertificateService.VerificationResult result = service.verifyById("0xCertId123");

        assertThat(result.isRevoked()).isTrue();
    }

    @Test
    @DisplayName("verifyById – missing certificate returns NOT_FOUND")
    void verifyById_notFound() {
        when(repository.findByCertId(any())).thenReturn(Optional.empty());

        CertificateService.VerificationResult result = service.verifyById("0xMissing");

        assertThat(result.isNotFound()).isTrue();
    }

    @Test
    @DisplayName("verifyByFile – matching hash returns VALID")
    void verifyByFile_matchingHash() throws Exception {
        byte[] content = "certificate pdf bytes".getBytes();
        MockMultipartFile file = new MockMultipartFile("file", "cert.pdf",
                "application/pdf", content);
        String expectedHash = "0x" + DigestUtils.sha256Hex(content);

        CertificateRecord rec = validRecord();
        rec.setCertHash(expectedHash);
        when(repository.findByCertHash(expectedHash)).thenReturn(Optional.of(rec));

        CertificateService.VerificationResult result = service.verifyByFile(file);

        assertThat(result.isValid()).isTrue();
    }

    // ── Revoke ────────────────────────────────────────────────────────────────

    @Test
    @DisplayName("revoke – issuer can revoke their own certificate")
    void revoke_byIssuer() throws Exception {
        CertificateRecord rec = validRecord();
        when(repository.findByCertId("0xCertId123")).thenReturn(Optional.of(rec));
        when(blockchainService.revokeCertificate(anyString())).thenReturn("0x" + "b".repeat(64));
        when(repository.save(any())).thenAnswer(inv -> inv.getArgument(0));

        CertificateRecord result = service.revoke("0xCertId123", ISSUER);

        assertThat(result.isRevoked()).isTrue();
    }

    @Test
    @DisplayName("revoke – wrong issuer throws SecurityException")
    void revoke_wrongIssuer() {
        CertificateRecord rec = validRecord();
        when(repository.findByCertId("0xCertId123")).thenReturn(Optional.of(rec));

        assertThatThrownBy(() -> service.revoke("0xCertId123", "0xWrong"))
                .isInstanceOf(SecurityException.class)
                .hasMessageContaining("Only the original issuer");
    }

    @Test
    @DisplayName("revoke – already-revoked certificate throws IllegalStateException")
    void revoke_alreadyRevoked() {
        CertificateRecord rec = validRecord();
        rec.setRevoked(true);
        when(repository.findByCertId("0xCertId123")).thenReturn(Optional.of(rec));

        assertThatThrownBy(() -> service.revoke("0xCertId123", ISSUER))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("already revoked");
    }

    // ── Queries ───────────────────────────────────────────────────────────────

    @Test
    @DisplayName("findAll – delegates to repository")
    void findAll() {
        when(repository.findAll()).thenReturn(List.of(validRecord()));
        assertThat(service.findAll()).hasSize(1);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private CertificateRecord validRecord() {
        return CertificateRecord.builder()
                .certId("0xCertId123")
                .certHash("0x" + "a".repeat(64))
                .ipfsCid("QmFakeCid")
                .issuerAddress(ISSUER)
                .recipientAddress("0x1234")
                .recipientName("Alice")
                .courseName("Java Dev")
                .issuedAt(Instant.now())
                .txHash("0x" + "b".repeat(64))
                .revoked(false)
                .build();
    }
}
