package com.skincertchain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * SkincertChain – Blockchain Certificate Verification System
 * Entry point for the Spring Boot application.
 */
@SpringBootApplication
public class SkincertChainApplication {

    public static void main(String[] args) {
        SpringApplication.run(SkincertChainApplication.class, args);
    }
}
